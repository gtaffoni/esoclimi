#!/usr/bin/python


"""
Read (time,latitude,albedo) files written by Energy Balance Model
Display and create image of albedo versus time and latitude
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm  
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
 


import sys  

try:    
    model=sys.argv[1]
except: 
    print "SYNTAX: albedoMAP.py label"
    model='' 


inpfile='Risultati/year_lat_alb.tla' 

outfile='Risultati/Figs/mapAlbedo_%s.pdf'%model
#
#Nt=520 # number of pixels in time
#Nl=145 # number of pixels in latitude

#plt.rcParams['font.size']=14

f=open(inpfile,'r')

line=f.readline()
e=line.split()
Nt=int(e[0])   # number of pixels in time
Nl=int(e[1])   # number of pixels in latitude


time=np.zeros((Nt),float)      # inizialization of empty vector for time
lat =np.zeros((Nl),float)      # inizialization of empty vector for latitudes
Alb=np.zeros((Nl,Nt),float)   # inizialization of empty images for temperatures


for i in range(Nt):
    for j in range(Nl):
        line=f.readline()
	e=line.split()
	time[i]=float(e[0])
	lat[j] =float(e[1])
	Alb[j,i]=float(e[2])  # image is transposed: [j,i] instead of [i,j]
time=time-int(time[0]) #+0.5*(1./float(Nt))
#plt.figure(figsize=(10,8)) 
 
 
fig,ax=plt.subplots(1,1,1) 

AlbLevels=np.arange(0.,1.05,0.05)
Amin=0.
Amax=1. 

plt.title('Albedo seasonal cycle (EBM %s)'%model)

plt.xlabel('Time (yr)',fontsize=20) 
plt.ylabel('Latitude ($^\circ$N)',fontsize=20)  

plt.xticks([0.,0.2,0.4,0.6,0.8,1.],fontsize=18)
plt.yticks([-80.,-60.,-40,-20.,0.,20.,40,60.,80.],fontsize=18)

plt.axis([0,1,-90,90])

plt.contourf(time,lat,Alb,levels=AlbLevels,cmap=plt.cm.rainbow #ocean #gray #ocean #gist_earth #afmhot
            ,norm=plt.normalize(vmax=Amax,vmin=Amin)) #,alpha=0.5) 
cb=plt.colorbar(shrink=1.0,ticks=[0,.2,.4,.6,.8,1])
cb.set_label('Albedo') 
plt.savefig(outfile)
#plt.show()
