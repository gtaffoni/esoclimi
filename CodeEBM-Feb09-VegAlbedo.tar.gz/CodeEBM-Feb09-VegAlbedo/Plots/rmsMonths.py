#!/usr/bin/python

import numpy as np
from math import *

from moduleREAD import * 
from jRebin import jRebin
from vCalc import LinInterp

import sys 


try:    
    model=sys.argv[1]
except: 
    print "SYNTAX: rmsMonths.py label"
    model=''

# OUTFILE
 
outfile=open('Risultati/rmsMonths_%s.txt'%model,'w')
outfile.write('#STATISTICS FOR THE NORTHERN HEMISPHERE\n')
outfile.write('# month    Tobs    Tmod       wtRMS\n')
 
# INIZIALIZZAZIONE PLOT
plotoption=False
plotoption=raw_input('Plot seasonal evolution? [n]: ')
if 'y' in plotoption or 'Y' in plotoption: plotoption=True  

if plotoption:
   import matplotlib.pylab as plt  

   xlabel='Latitude'  
   ylabel='Temperature'  
   

# GRIGLIA IN LATITUDINE DEL MODELLO 

theta,tmod=read2('Risultati/ZonalData.txt',1,2)
Nmod=len(theta)

xmin=-np.pi/2. 
xmax=+np.pi/2. 
dx = (xmax-xmin)/Nmod 

bin=dx*180./np.pi 

# INIZIALIZZAZIONE DATI OSSERVATIVI

obsfile='erai_t2m_monthly_annual.txt' # dati Terra Antonello 

lat0,temp0=read2(obsfile,1,2)    # DATI OSSERVATIVI
                                 # LATITUDINI DECRESCENTI

Nobs=len(lat0)

lat1 =np.zeros((Nobs,),float)
for k in range(Nobs):
   lat1[k] =lat0[Nobs-k-1]       # LATITUDINI CRESCENTI

# CONFRONTO NUMERO PUNTI MODELLO/OSSERVAZIONI

if Nmod < Nobs:
   mode='rebin' # modo rebin

if Nmod >= Nobs:
   mode='interp' # modo interpolazione

# INIZIALIZZAZIONE LOOP SULLE STAGIONI

monthfilelist=['ZonalTemp300','ZonalTemp330','ZonalTemp360','ZonalTemp030',\
               'ZonalTemp060','ZonalTemp090','ZonalTemp120','ZonalTemp150',\
	       'ZonalTemp180','ZonalTemp210','ZonalTemp240','ZonalTemp270',\
	       'ZonalData']   
	       
monthlist=['01-jan','02-feb','03-mar','04-apr',\
           '05-may','06-jun','07-jul','08-aug',\
	   '09-sep','10-oct','11-nov','12-dec',\
	   'ANNUAL']	   

Tmodlist=[]

icolmonth=1     # indice della colonna da leggere
ilabelmonth=-1

totsqw=0.
totsq=0.  

kfig=0
Ns=0    # numero di mesi

maxTmonth=0.
minTmonth=1000.

print
print 'STATISTICS CALCULATED FOR THE NORTHERN HEMISPHERE'

for monthfile in monthfilelist:
   monthfile='Risultati/'+monthfile+'.txt'
   
   ilabelmonth += 1 
   month = monthlist[ilabelmonth] 

   icolmonth += 1  
   lat0,temp0=read2(obsfile,1,icolmonth)   # DATI OSSERVATIVI
                                           # LATITUDINI DECRESCENTI 
   temp1=np.zeros((Nobs,),float) 

   for k in range(Nobs):            # DATI OSSERVATIVI
                                    # LATITUDINI CRESCENTI 
      temp1[k]=temp0[Nobs-k-1]  
 
   tempobs=np.zeros((Nmod,),float)

   if mode == 'rebin':              # se Nmod < Nobs 
      for i in range(Nmod):         # DATI OSSERVATIVI 
                                    # REBINNATI ALLE LATITUDINI DEL MODELLO 
         tempobs[i]=jRebin(lat1,temp1,theta[i],bin)
	 
   if mode == 'interp':             # se Nmod >= Nobs
      for i in range(Nmod):         # DATI OSSERVATIVI 
                                    # INTERPOLATI ALLE LATITUDINI DEL MODELLO 
         tempobs[i]=LinInterp(lat1,temp1,theta[i])
   
   
   latmod,tempmod=read2(monthfile,1,2)  # DATI MODELLO
   Tmod=0.
   Tobs=0. 
   w=0.
   
   TobsNoPoles=0.
   wNoPoles=0.
   
   for i in range(Nmod):
      if latmod[i] <0.: continue  ##  NORTH HEMISPHERE
      Tmod += tempmod[i]*cos(latmod[i]*np.pi/180.)
      Tobs += tempobs[i]*cos(latmod[i]*np.pi/180.)
      w    += cos(latmod[i]*np.pi/180.)
      
      if -75. < latmod[i] < +75.:
         TobsNoPoles += tempobs[i]*cos(latmod[i]*np.pi/180.)
	 wNoPoles    += cos(latmod[i]*np.pi/180.)
      
   Tmod=Tmod/w
   Tobs=Tobs/w
   
   TobsNoPoles=TobsNoPoles/wNoPoles 
   
    
   sq=0.
   sqw=0.
   sumwt=0.
   for i in range(Nmod):
      
      if latmod[i] <0.: continue  ##  NORTH HEMISPHERE
      
      #  SCARTI PESATI E NORMALIZZATI SULL'AREA 
      
      wt = cos(theta[i]*np.pi/180.) 
      sumwt += wt
      sqw += wt*(tempobs[i]-tempmod[i])**2
      
      sq += (tempobs[i]-tempmod[i])**2
   
   sqw=np.sqrt( sqw/sumwt )
   sq =np.sqrt( sq/(Nmod-1) )
   
   print '%-12s  Tobs: %8.4f   Tmod: %8.4f   RMS: %8.4f   wtRMS: %8.4f  Tobs(no poles): %8.4f' \
         % (month,Tobs-273.15,Tmod-273.15,sq,sqw,\
	 TobsNoPoles-273.15) 
   
   outrow='%-9s %8.4f %8.4f %8.4f\n' % (month,Tobs,Tmod,sqw)
   outfile.write(outrow)
   
   if 'ANNUAL' not in month:
      Ns += 1                   # conta i mesi
      totsqw = totsqw+sqw
      totsq  = totsq+sq
      
      Tmodlist.append(Tmod)
      minTmonth=min(minTmonth,Tmod)
      maxTmonth=max(maxTmonth,Tmod)

   if plotoption:
      kfig += 1
      plt.figure(num=kfig)
      plt.xlabel(xlabel,fontsize='16')
      plt.ylabel(ylabel,fontsize='16')
      plt.title(month+' %s'%model)

      plt.xlim(-90,90)
      plt.xticks([-90.,-60.,-30.,0.,30.,60.,90.])
      plt.ylim(220,330)

      plt.plot(latmod,tempmod,'co')  
      plt.plot(theta,tempobs,'rx')

      plt.plot(lat0,temp0,'r-') 
      ff='Risultati/Figs/templat_%s_'%model+month+'.pdf'
      plt.savefig(ff)
#      plt.show()
 
totsqw=totsqw/Ns
totsq =totsq/Ns

# IDENTIFY MONTHES OF MINIMUM AND MAXIMUM TEMPERATURE 

ilabelmonth=-1
for Tmod in Tmodlist: 

   ilabelmonth += 1 
   month = monthlist[ilabelmonth]
   
   if Tmod == minTmonth:
      print 'Tmin=%6.3f (%s) ' % (minTmonth-273.15,month),
   if Tmod == maxTmonth:
      print 'Tmax=%6.3f (%s) ' % (maxTmonth-273.15,month),
   

print 'DTseasonal=%6.3f ' %  (maxTmonth-minTmonth)

#print 'MEAN SEASONAL                                   RMS: %8.4f   wtRMS: %8.4f' \
#      % (totsq,totsqw) 
