import numpy as np
import pylab as plt

def tempcomp(i):
    y,x,t=np.loadtxt('Risultati.Std/year_lat_temp_last1.tlt',skiprows=1,unpack=True)
    xstd=x[i*54:i*54+54]
    tstd=t[i*54:i*54+54]
    y,x,t=np.loadtxt('Risultati.VegPassive/year_lat_temp_last1.tlt',skiprows=1,unpack=True)
    xvpass=x[i*54:i*54+54]
    tvpass=t[i*54:i*54+54]
    y,x,t=np.loadtxt('Risultati.VegAFB.010/year_lat_temp_last1.tlt',skiprows=1,unpack=True)
    xvafb010=x[i*54:i*54+54]
    tvafb010=t[i*54:i*54+54]
    y,x,t=np.loadtxt('Risultati.VegAFB.012/year_lat_temp_last1.tlt',skiprows=1,unpack=True)
    xvafb012=x[i*54:i*54+54]
    tvafb012=t[i*54:i*54+54]
    y,x,t=np.loadtxt('Risultati.VegAFB.015/year_lat_temp_last1.tlt',skiprows=1,unpack=True)
    xvafb015=x[i*54:i*54+54]
    tvafb015=t[i*54:i*54+54]
    
    bfr="season %d"%i

    plt.clf()
    plt.title(bfr)
    plt.scatter(xstd,tstd,s=3.0,color='black')
    plt.scatter(xvpass,tvpass,s=3.0,color='red')
    plt.scatter(xvafb010,tvafb010,s=3.0,color='green')
    plt.scatter(xvafb012,tvafb012,s=3.0,color='cyan')
    plt.scatter(xvafb015,tvafb015,s=3.0,color='blue')
    plt.plot(xstd,tstd,label='Std',color='black')
    plt.plot(xvpass,tvpass,label='Veg passive',color='red')
    plt.plot(xvafb010,tvafb010,label='Veg AFB alb=0.10',color='green')
    plt.plot(xvafb012,tvafb012,label='Veg AFB alb=0.12',color='cyan')
    plt.plot(xvafb015,tvafb015,label='Veg AFB alb=0.15',color='blue')
    plt.legend(loc='best')
    plt.show()

    bfr="tempcomp-season%02d.png"%i
    plt.title(bfr)
    plt.scatter(xstd,tstd,s=3.0,color='black')
    plt.scatter(xvpass,tvpass,s=3.0,color='red')
    plt.scatter(xvafb010,tvafb010,s=3.0,color='green')
    plt.scatter(xvafb012,tvafb012,s=3.0,color='cyan')
    plt.scatter(xvafb015,tvafb015,s=3.0,color='blue')
    plt.plot(xstd,tstd,label='Std',color='black')
    plt.plot(xvpass,tvpass,label='Veg passive',color='red')
    plt.plot(xvafb010,tvafb010,label='Veg AFB alb=0.10',color='green')
    plt.plot(xvafb012,tvafb012,label='Veg AFB alb=0.12',color='cyan')
    plt.plot(xvafb015,tvafb015,label='Veg AFB alb=0.15',color='blue')
    plt.legend(loc='best')
    bfr="tempcomp-season%02d.png"%i
    plt.savefig(bfr)

    
    return
