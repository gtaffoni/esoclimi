#!/usr/bin/python

import numpy as np
from moduleREAD import *
import matplotlib.pylab as plt 
from libraryEBM import LWTR

import sys  

try:    
    model=sys.argv[1]
except: 
    print "SYNTAX: zonalplots.py label"
    model='' 

ebmfile='Risultati/ZonalData.txt'

vf=open('Risultati/valori.txt','r')
vd=vf.readline().split()

sma=float(vd[2])
logpress=np.log10(float(vd[8]))
meanT=float(vd[11])
fhab=float(vd[13])

T=meanT
press=10**(logpress)

pws=(np.exp(77.3450+0.0057*T-7235/T)/T**8.2) # saturated water vapor (Pa)
RH=0.5
pTOT= press + RH*pws


iy=14 

#TWmin,TWmax=LWTR(pTOT)

plt.rcParams['font.size']=14
xlabel='Latitude [$^\circ$N]' 

#############   PLOT ZONAL TEMPERATURE

plt.figure() #(figsize=(8,8)) 

#latEARTH,tempEARTH=read2(inpfile2,1,iy) 
#plt.plot(latEARTH,tempEARTH,color='0.5',marker='o',markersize=5,linewidth=0) 

latEBM,tempEBM=read2(ebmfile,1,2)
plt.plot(latEBM,tempEBM,'k-',linewidth=1.5) 

datafile='/Users/vladilo/work/res/climates/earthData/ERA_2001-2013/zonalTempERA.txt'
latERA,tempERA=read2(datafile,1,2) 
plt.plot(latERA,tempERA,color='m',marker='x',markersize=5,linewidth=0)  

#plt.plot([-90,90],[TWmin,TWmin],'b--',linewidth=2)
#plt.plot([-90,90],[TWmax,TWmax],'r--',linewidth=2)
#
#plt.plot([-90,90],[meanT,meanT],'m-',linewidth=1)

#s='a=%5.2f AU, log p(bar)=%5.2f, h=%5.2f' % (sma,np.log10(pTOT/1.e5),fhab)
#plt.text(0.,340.,s,horizontalalignment='center',fontsize=18)

plt.xlabel(xlabel,fontsize='18')
#
ylabel='Temperature [K]' 
plt.ylabel(ylabel,fontsize='18')

plt.xlim(-90,90)
plt.xticks([-90.,-60.,-30.,0.,30.,60.,90.])
plt.ylim(215,335)
#plt.ylim(220,450)
plt.title('model %s'%model)
plotfile='Risultati/Figs/zonalTEMP_%s.pdf' % model
plt.savefig(plotfile,dpi=300) 

#############   PLOT ZONAL ALBEDO

plt.figure() #(figsize=(8,8)) 
 
latEBM,albEBM=read2(ebmfile,1,6) 
plt.plot(latEBM,albEBM,'k-',linewidth=1.5) 
print 'ALBmin(EBM)=%.3f'%min(albEBM)

datafile='/Users/vladilo/work/res/climates/earthData/CERES_2001-2013/zonalAlbedoCERES.txt'
latCERES,albCERES=read2(datafile,1,2) 
plt.plot(latCERES,albCERES,color='m',marker='x',markersize=5,linewidth=0)  
print 'ALBmin(CERES)=%.3f'%min(albCERES)

plt.xlabel(xlabel,fontsize='18')
#
ylabel='Albedo [K]' 
plt.ylabel(ylabel,fontsize='18')

plt.xlim(-90,90)
plt.xticks([-90.,-60.,-30.,0.,30.,60.,90.])
plt.ylim(-0.01,1.05)
#plt.ylim(220,450)
plt.title('model %s'%model)
plotfile='Risultati/Figs/zonalALB_%s.pdf' % model
plt.savefig(plotfile,dpi=300) 

#############   PLOT ZONAL OLR & ARS (ABSORBED STELLAR RADIATION)

plt.figure() #(figsize=(8,8)) 

latEBM,zonalOLR,zonalASR=read3(ebmfile,1,4,5)
plt.plot(latEBM,zonalOLR,'k--',linewidth=1.5,label='OLR') 
plt.plot(latEBM,zonalASR,'k:',linewidth=1.5,label='ASR')

plt.xlabel(xlabel,fontsize='18')
ylabel='OLR/ASR [W/m2]' 
plt.ylabel(ylabel,fontsize='18')

plt.legend()
plt.xlim(0,90)
plt.xticks([-90.,-60.,-30.,0.,30.,60.,90.])

plt.ylim(0,450) 

plt.title('model %s'%model)

plotfile='Risultati/Figs/zonalOLR_ASR_%s.pdf' % model
plt.savefig(plotfile,dpi=300) 


#############   PLOT ZONAL ENERGY FLUX

plt.figure() #(figsize=(8,8)) 

latEBM,atmfluxEBM,dryfluxEBM=read3(ebmfile,1,8,9) 

atmfluxEBM=atmfluxEBM/1.e15 # conversion to PW
dryfluxEBM=dryfluxEBM/1.e15
plt.plot(latEBM,atmfluxEBM,'k-',linewidth=1.5,label='total') 
plt.plot(latEBM,atmfluxEBM-dryfluxEBM,'c:',linewidth=1.5,label='moist') 
plt.plot(latEBM,dryfluxEBM,'r--',linewidth=1.5,label='dry') 

plt.legend(loc='upper left')

print 'max atmospheric flux=%.2e' % max(atmfluxEBM)

#s='a=%5.2f AU, log p(bar)=%5.2f, h=%5.2f' % (sma,np.log10(pTOT/1.e5),fhab)
#plt.text(0.,0.8,s,horizontalalignment='center',fontsize=18)

plt.xlabel(xlabel,fontsize='18')
#
ylabel='Energy flux [PW]' 
plt.ylabel(ylabel,fontsize='18')

plt.xlim(0,90)
plt.xticks([-90.,-60.,-30.,0.,30.,60.,90.])
#plt.xticks([0.,30.,60.,90.])
plt.ylim(-8.,8.0) 

plt.title('model %s'%model)

plotfile='Risultati/Figs/zonalATMFLUX_%s.pdf' % model
plt.savefig(plotfile,dpi=300) 

#plt.show()
