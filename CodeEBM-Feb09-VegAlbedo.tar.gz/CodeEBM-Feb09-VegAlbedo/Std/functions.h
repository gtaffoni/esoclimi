c function declarations
       real*8 dlat, Cterm, Dterm, Iterm, lininterp, Aterm
       real*8 alb_z, Sterm
       real*8 f_ice, icecover, P_H2O
       real*8 DiurnalMeanMu
